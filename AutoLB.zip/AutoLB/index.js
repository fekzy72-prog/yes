/// <reference types="../CTAutocomplete" />
/// <reference lib="es2015" />

import { onTick } from "../ServerTick"

const EnableLB = new KeyBind("Enable", Keyboard.KEY_NONE, "Auto LB");

// get the existing use item keybind
const UseItemKeybind = Client.getMinecraft().field_71474_y.field_74313_G;
const UseItemKeyCode = UseItemKeybind.func_151463_i();

let debuffMode = false;
let bowDrawnTicks = 0;

register("tick", () => {
    if (EnableLB.isPressed()) {
        debuffMode = !debuffMode;
        ChatLib.chat("&c&lAuto LBMode: &7" + debuffMode);
    }
})

// server tick
onTick(() => {
    const thePlayer = Client.getMinecraft().field_71439_g;
    const playerController = Client.getMinecraft().field_71442_b;

    if (!thePlayer.func_71039_bw()) {
        bowDrawnTicks = 0;
    } else {
        bowDrawnTicks++;
    }

    if (debuffMode) {
        const item = thePlayer.func_70694_bm();

        if (item == null || !item.func_82833_r().toLowerCase().includes("last breath")) return;

        const optimalTime = 11;

        if (bowDrawnTicks >= optimalTime) {
            bowDrawnTicks = 0;

            if (thePlayer.func_71039_bw()) {
                playerController.func_78766_c(thePlayer);
                if (UseItemKeybind.func_151470_d()) {
                    UseItemKeybind.func_74510_a(UseItemKeyCode, false);

                    setTimeout(() => {
                        UseItemKeybind.func_74510_a(UseItemKeyCode, true);
                    }, Math.floor(Math.random() * 100) + 35);
                }
            }
        }
    }
})